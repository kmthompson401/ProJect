import { View, Text } from 'react-native'
import React from 'react' 

const Page = () => {
    return (
        <View>  
            <text>BOOK</text>
        </View>
    );
};

export default Page